# React Documentation Index

## Categories

### Api
**File:** `api.md`
**Pages:** 2

### Components
**File:** `components.md`
**Pages:** 9

### Getting Started
**File:** `getting_started.md`
**Pages:** 3

### Hooks
**File:** `hooks.md`
**Pages:** 2

### Other
**File:** `other.md`
**Pages:** 13
