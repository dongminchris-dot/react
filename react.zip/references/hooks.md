# React - Hooks

**Pages:** 2

---

## Built-in React Hooks

**URL:** https://react.dev/reference/react/hooks

**Contents:**
- Built-in React Hooks
- State Hooks
- Context Hooks
- Ref Hooks
- Effect Hooks
- Performance Hooks
- Other Hooks
- Your own Hooks

Hooks let you use different React features from your components. You can either use the built-in Hooks or combine them to build your own. This page lists all built-in Hooks in React.

State lets a component “remember” information like user input. For example, a form component can use state to store the input value, while an image gallery component can use state to store the selected image index.

To add state to a component, use one of these Hooks:

Context lets a component receive information from distant parents without passing it as props. For example, your app’s top-level component can pass the current UI theme to all components below, no matter how deep.

Refs let a component hold some information that isn’t used for rendering, like a DOM node or a timeout ID. Unlike with state, updating a ref does not re-render your component. Refs are an “escape hatch” from the React paradigm. They are useful when you need to work with non-React systems, such as the built-in browser APIs.

Effects let a component connect to and synchronize with external systems. This includes dealing with network, browser DOM, animations, widgets written using a different UI library, and other non-React code.

Effects are an “escape hatch” from the React paradigm. Don’t use Effects to orchestrate the data flow of your application. If you’re not interacting with an external system, you might not need an Effect.

There are two rarely used variations of useEffect with differences in timing:

A common way to optimize re-rendering performance is to skip unnecessary work. For example, you can tell React to reuse a cached calculation or to skip a re-render if the data has not changed since the previous render.

To skip calculations and unnecessary re-rendering, use one of these Hooks:

Sometimes, you can’t skip re-rendering because the screen actually needs to update. In that case, you can improve performance by separating blocking updates that must be synchronous (like typing into an input) from non-blocking updates which don’t need to block the user interface (like updating a chart).

To prioritize rendering, use one of these Hooks:

These Hooks are mostly useful to library authors and aren’t commonly used in the application code.

You can also define your own custom Hooks as JavaScript functions.

**Examples:**

Example 1 (jsx):
```jsx
function ImageGallery() {  const [index, setIndex] = useState(0);  // ...
```

Example 2 (javascript):
```javascript
function Button() {  const theme = useContext(ThemeContext);  // ...
```

Example 3 (javascript):
```javascript
function Form() {  const inputRef = useRef(null);  // ...
```

Example 4 (javascript):
```javascript
function ChatRoom({ roomId }) {  useEffect(() => {    const connection = createConnection(roomId);    connection.connect();    return () => connection.disconnect();  }, [roomId]);  // ...
```

---

## React Compiler

**URL:** https://react.dev/learn/react-compiler

**Contents:**
- React Compiler
- Introduction
- Installation
- Incremental Adoption
- Debugging and Troubleshooting
- Configuration and Reference
- Additional resources

Learn what React Compiler does and how it automatically optimizes your React application by handling memoization for you, eliminating the need for manual useMemo, useCallback, and React.memo.

Get started with installing React Compiler and learn how to configure it with your build tools.

Learn strategies for gradually adopting React Compiler in your existing codebase if you’re not ready to enable it everywhere yet.

When things don’t work as expected, use our debugging guide to understand the difference between compiler errors and runtime issues, identify common breaking patterns, and follow a systematic debugging workflow.

For detailed configuration options and API reference:

In addition to these docs, we recommend checking the React Compiler Working Group for additional information and discussion about the compiler.

---
